import logging
import openai
from telegram import Update
from telegram.ext import (
    ApplicationBuilder, CommandHandler,
    MessageHandler, ContextTypes, filters
)

TELEGRAM_BOT_TOKEN = '8008584816:AAG3qTLQRl6GwQ9yzV8d9qLitRzPPv9X2H8'
OPENAI_API_KEY = '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'
openai.api_key = OPENAI_API_KEY

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

LANGUAGES = {
    "ua": "Ти корисний український помічник.",
    "en": "You are a helpful assistant.",
    "ru": "Ты полезный помощник."
}
user_languages = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Привіт! Я AI бот. Вибери мову командою /lang ua | en | ru.\nАбо просто напиши запит."
    )

async def set_language(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if context.args and context.args[0].lower() in LANGUAGES:
        lang = context.args[0].lower()
        user_languages[user_id] = lang
        await update.message.reply_text(f"Мова змінена на: {lang.upper()}")
    else:
        await update.message.reply_text("Приклад: /lang ua | en | ru")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_input = update.message.text
    user_id = update.effective_user.id
    lang = user_languages.get(user_id, "ua")

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": LANGUAGES[lang]},
                {"role": "user", "content": user_input}
            ]
        )
        reply = response['choices'][0]['message']['content']
    except Exception as e:
        reply = f"Помилка: {str(e)}"

    await update.message.reply_text(reply)

async def main():
    app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("lang", set_language))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    print("Бот запущено...")
    await app.run_polling()

if __name__ == '__main__':
    import asyncio
    asyncio.run(main())
