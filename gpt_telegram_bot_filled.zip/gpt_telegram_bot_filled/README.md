# GPT Telegram Bot (зі вставленими токенами)

Цей бот використовує OpenAI GPT-3.5 для відповіді на запити користувачів через Telegram.

## Команди

- `/start` — запуск бота
- `/lang ua|en|ru` — вибір мови відповіді

## Запуск

1. Встанови залежності:
```
pip install -r requirements.txt
```

2. Запусти:
```
python main.py
```
